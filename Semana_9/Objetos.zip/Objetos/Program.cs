﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Objetos
{
    internal class Mate
    {
        public double alCuadrado()
        {
            double  num, val;
            Console.WriteLine("Ingrese número a elevar");
            num= Convert.ToInt32(Console.ReadLine());
            val = num *num;
            return val; 
        }
        public void mostrarPAr()
        {
            double num;
            Console.WriteLine("Ingrese un número a evaluar");
            num = Convert.ToInt32(Console.ReadLine());

            if (num%2 == 0)
            {
                Console.WriteLine($"El número {num} es par");
            }
            else
            {
                Console.WriteLine($"El número {num} no es par");
            }
        }
        static void Main()
        {
            Mate Lamate = new Mate();
            double res = Lamate.alCuadrado();
            Console.WriteLine(res);
            Lamate.mostrarPAr();
        }
    }
}
