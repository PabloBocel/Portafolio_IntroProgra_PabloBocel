﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace case_break
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese día");
            int día = Convert.ToInt32(Console.ReadLine());

            switch (día){
                case 1: Console.WriteLine("Lunes");
                    break;
                case 2: Console.WriteLine("Martes");
                    break; 
                case 3: Console.WriteLine("Miércoles");
                    break;
                case 4: Console.WriteLine("Jueves");
                    break;
                case 5: Console.WriteLine("Viernes");
                    break;
                case 6: Console.WriteLine("Sábado");
                    break;
                case 7: Console.WriteLine("Fin de semana");
                    break;
                default: Console.WriteLine("Día Inválido");
                    break;
            }
            Console.ReadKey();
        }
    }
}
