﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejerciciosemana10
{
    public class Cafetera
    {
        public string codeinventario;
        public int capacidadTazas;
        public int tazasDisponibles;
        public int tazasServidas;
        public bool lleno; 

        public Cafetera(string codigo, int capacidad)
        {
            codeinventario = codigo;
            capacidadTazas = capacidad;
            tazasDisponibles = 0;
            tazasServidas = 0;
        }

        public void HacerCafe()
        {
            tazasDisponibles = capacidadTazas;
            tazasServidas = 0;
            lleno = true;
        }

        public bool ServirTaza(int cantidad)
        {
            if (cantidad <= tazasDisponibles)
            {
                tazasDisponibles -= cantidad;
                tazasServidas += cantidad;
                return true;
            }
            else
            {
                Console.WriteLine("No hay suficientes tazas disponibles");
                return false;
            }
        }

        public double ObtenerPorcentajeDisponibilidad()
        {
            return ((double)tazasDisponibles / (double)capacidadTazas) * 100.0;
        }
        public void mostrarEstado()
        {
            string texto = codeinventario+"capacidad:"+capacidadTazas+"tazas servidas"+(capacidadTazas-tazasDisponibles);
        }

        static void Main(string[] args)
        {
            string c = ("200");
            string codigo = c;
            int cap = 0;
            Console.WriteLine("Ingrese capacidad de tazas");
            cap = Convert.ToInt32(Console.ReadLine());
            int capacidad = cap; 

            Cafetera cafetera = new Cafetera(codigo, capacidad);

            cafetera.HacerCafe();
            int a = 0;
            
            

            char opcion;
            do
            {
                Console.WriteLine("Cuantas tazas quiere servir");
                a = Convert.ToInt32(Console.ReadLine());
                int tazasAServir = a;
                cafetera.ServirTaza(tazasAServir);
                cafetera.mostrarEstado();

                Console.WriteLine("Desea ingresar más tazas? s/n");
                opcion = Convert.ToChar(Console.ReadLine().ToLower());
            } while (opcion == 's');
            

            

            Console.WriteLine("\nCAFETERA:");
            Console.WriteLine("Código de inventario:" + cafetera.codeinventario);
            Console.WriteLine("Capacidad: {0} tazas", cafetera.capacidadTazas);
            Console.WriteLine("Tazas disponibles: {0}", cafetera.tazasDisponibles);
            Console.WriteLine("Tazas servidas: {0}", cafetera.tazasServidas);
            Console.WriteLine("Porcentaje de disponibilidad: {0}%", cafetera.ObtenerPorcentajeDisponibilidad());
            Console.ReadKey();
        }
    }
}
