﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioIndividual2Semana10
{
    public class Pelicula
    {
        private string nombre;
        private double duracíon;
        private string genero;
        private int año;
        private double calificacion;

        public Pelicula ()
        {
            nombre = " ";
            duracíon = 0;
            año = 0;
            calificacion = 0;
        }
       
        public bool esPeliculaEpica ()
        {
            if (duracíon >= 3)
            {
                return true;
            }
            else 
            {
                return false;
            }
        }
        public string valoracion ()
        {
            if (calificacion > 0 && calificacion <= 2)
            {
                return "Muy mala";
            }
            else if (calificacion > 2 && calificacion <= 5)
            {
                return "Mala";
            }
            else if (calificacion > 5 && calificacion <= 7)
            {
                return "Regular";
            }
            else if (calificacion > 7 && calificacion <= 8 )
            {
                return "Buena";
            }
            else if (calificacion > 8 && calificacion <= 10)
            {
                return "Excelente";
            }
            else
            {
                return "Ingrese una calificación del 1 al 10";
            }
        }
        static bool esSimilar (string genero1, string genero2, double calificacion1, double calificacion2)
        {
            if (genero1 == genero2 &&  calificacion1 == calificacion2) 
            { 
                return true; 
            }
            else 
            { 
                return false;
            }
        }
        public string MostrarInformacion ()
        {
            return $"El nombre de la película es: {nombre}, esta tiene una duración de {duracíon} horas, el género es {genero}, publicada en el año {año}";
        }

        static void Main(string[] args)
        {
            Console.WriteLine("\nPelícula número 1");
            Pelicula myPelicula = new Pelicula();
            myPelicula.nombre = "Gandhi";
            myPelicula.genero = "Drama";
            myPelicula.duracíon = 3.18;
            myPelicula.año = 1982;
            myPelicula.calificacion = 8.1;
            Console.WriteLine(myPelicula.MostrarInformacion());
            Console.WriteLine("La película es épica? "+myPelicula.esPeliculaEpica());
            Console.WriteLine("La valoración de la película es: "+ myPelicula.valoracion());

            Console.WriteLine("\nPelícula número 2");
            Pelicula pelicula2 = new Pelicula();
            pelicula2.nombre= "Thor";
            pelicula2.genero = "Acción";
            pelicula2.duracíon = 1.9;
            pelicula2.año = 2011;
            pelicula2.calificacion = 7;
            Console.WriteLine(pelicula2.MostrarInformacion());
            Console.WriteLine("La película es épica? " + pelicula2.esPeliculaEpica());
            Console.WriteLine("La valoración de la película es: " + pelicula2.valoracion());

            Console.WriteLine("\nLas películas son similares? " + esSimilar(pelicula2.genero, myPelicula.genero, pelicula2.calificacion, myPelicula.calificacion));
            Console.ReadKey();
        }
    }
}
