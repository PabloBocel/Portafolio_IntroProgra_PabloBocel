﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace codigo_2
{
    internal class Program
    {
        static void Main(string[] args)
            //ingrese si es mayor o menor de edad
        {
            Console.WriteLine("Ingrese edad");
            int edad =Convert.ToInt32(Console.ReadLine());

            // si es un numero mayor que 0


            if (edad >=13 && edad <=17)
            {
                Console.WriteLine("Es mayor de edad");
            }
            else if (edad >=0 && edad <= 12)
            {
                Console.WriteLine("Niñ@");
            }
            else if (edad < 0)
            {
                Console.WriteLine("Edad inválida");
            }
            else if (edad >= 18 && edad <= 30)
            {
                Console.WriteLine("Adulto");
            }
            else if (edad >= 31 && edad <= 50)
            {
                Console.WriteLine("Mediana edad");
            }
            else if (edad >= 51)
            {
                Console.WriteLine("Tercera edad");
            }
            Console.ReadKey();
        }
        
    }
}
