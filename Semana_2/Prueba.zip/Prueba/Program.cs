﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prueba
{
    internal class Program
    {
        public int sumar(int x, int y)
        {
            int res = x + y;
            x++; 
            Console.WriteLine($"Valor de x es {x}");
            return res;
        }
        static void Main()
        {
            int a = 5;
            int b = 10;
            Program p = new Program();
            Console.WriteLine("Resultado " + p.sumar(a, b));
            Console.WriteLine("a: " + a);
            Console.ReadKey();
        }
        class calculos
        {
            public double calcularCircunferencia(  double radio, ref double circ)
            {
                double area = Math.PI * Math.Pow(radio, 2);
                double circunferencia = 2 * Math.PI * radio;
                circ = circunferencia;

                return area; 
            }
            static void Main()
            {
                calculos c = new calculos();
                Console.WriteLine("Ingrese el radio ");
                double r = Convert.ToDouble(Console.ReadLine());
                double aa, ci = 0;
                aa = c.calcularCircunferencia(r, ref ci);
                Console.WriteLine($"area {aa} Circunferencia {ci}");

                aa = c.calcularCircunferencia(7, ref ci);
                Console.WriteLine($"Area {aa} circunferencia {ci}");

                Console.ReadKey();
            }
        }
        
    
        
        
    }
}

