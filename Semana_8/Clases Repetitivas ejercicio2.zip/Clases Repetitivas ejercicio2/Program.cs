﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Clases_Repetitivas_ejercicio2
{
    internal class Program
    {
        static void Main(string[] args)
        {
                //Pablo Andres Bocel Morales 1109623, Christopher Javier Yuman Valdez 1160223
                Console.WriteLine("Ejercicio 2\n");
                int dia = 0;
                int sueldo = 70;
                double horas = 0;
                double mult; 
                int empleados = 0;
                double uno;
                char resp;

                do
                {
                    try
                    {
                        Console.WriteLine("Ingrese el número de empleados");
                        empleados = Convert.ToInt32(Console.ReadLine());

                        Console.WriteLine("Ingrese el número de horas trabajadas");
                        horas = Convert.ToDouble(Console.ReadLine());

                        Console.WriteLine("Ingrese el número de días trabajados");
                        dia = Convert.ToInt32(Console.ReadLine());
                    }
                    catch
                    {
                    Console.WriteLine("Dato invalido");
                    }
                        Console.WriteLine("Desea ingresar nuevos datos? s=si, n=no");
                        resp = Convert.ToChar(Console.ReadLine());
                       
 

                }
                while (resp == 's');
                {
                    mult = dia * horas * empleados * sueldo;
                    uno = dia * horas * sueldo;

                    Console.WriteLine($"La cantidad que pagó la empresa por {empleados} empleados fue {mult} quetzales con un sueldo de Q.{sueldo}");
                    Console.WriteLine($"La cantidad que se paga por cada empleado es de {uno} quetzales con un sueldo de Q.{sueldo}");
                }
                Console.ReadKey();
        }
    }
}
