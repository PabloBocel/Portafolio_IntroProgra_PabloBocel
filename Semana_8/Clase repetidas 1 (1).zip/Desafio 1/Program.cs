﻿class program
{
    static void Main()
    {
        //Pablo Andres Bocel Morales 1109623, Christopher Javier Yuman Valdez 1160223
        int meses = 19;
        int monto = 5;
        int resultado = 0;
        int cont = 0;
        int total = 0;
        do
        {
            monto = monto * 2;
            resultado = monto ;
            total = total + monto;
            cont++;
            Console.WriteLine("El monto que pago en el mes "+cont +" es de: "+ resultado);

        } while (meses >= cont );
        
        Console.WriteLine("El monto total que debe pagar es de: " + total);

    }

    
}
