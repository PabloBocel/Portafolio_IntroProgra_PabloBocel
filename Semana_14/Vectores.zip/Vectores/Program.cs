﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vectores
{
    internal class Program
    {
        static void Main(string[] args)
        {
            goto ejercicio2;
            double[] guardarnum = new double[1000];
             
            for (int i =0; i <= 10; i++)
            {
                guardarnum[i] = 0;
            }
            guardarnum[4] = 65;
            guardarnum[10] = 100;
            for (int i = 0; i <= 10; i++)
            {
                Console.WriteLine(i+"> "+guardarnum[i]);
            }
            Console.ReadKey();
            ejercicio2:

            int[] numeros = new int[10];
            for (int j = 0; j < 10; j++)
            {
                Console.WriteLine("Ingresar número ");
                numeros[j] = Convert.ToInt32(Console.ReadLine());
            }
            int suma = 0; 
            for (int j = 0; j < 10; j++)
            {
                suma = suma + numeros[j];
            }
            Console.WriteLine("Suma: "+suma);
            Console.ReadKey();
        }
    }
}
