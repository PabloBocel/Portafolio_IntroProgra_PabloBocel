﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dowhile
{
    internal class Program
    {
        static void Main(string[] args)
        {
            goto ejercicio2;
            double nota = 0;
            double promedio = 0, suma = 0;
            int cont = 0;
            char respuesta;
            do
            {
                Console.WriteLine("Ingrese nota");  
                nota = Convert.ToInt32(Console.ReadLine());
                suma = suma + nota;
                cont++;

                Console.WriteLine("Desea ingresar otra nota? s=si, n=no");
                respuesta =Convert.ToChar(Console.ReadLine()); 
            } while (respuesta == 's');
            promedio = suma / cont;
            Console.WriteLine("El promedio es " + promedio);
            Console.ReadKey();
        ejercicio2:
           
            int n = 0;

            Console.WriteLine("Ingrese un número");
            n = Convert.ToInt32(Console.ReadLine());

            for (int i = 1; i <= 100; i++)
            {
                if (i % n == 0)
                {
                    Console.WriteLine(i);
                }
                
                
            }
            Console.ReadKey();
        }
    }
}
