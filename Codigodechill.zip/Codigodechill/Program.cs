﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Codigodechill
{
    internal class Program
    {
        static void Main(string[] args)
        {
            dynamic vf = 0;
            dynamic vi = 0;
            dynamic a = 0;
            dynamic t = 0;
            


            Console.WriteLine("Ingrese variable");
            Console.WriteLine("\nSi la variable es tiempo escriba 1"+"\nSi la variable es velocidad final escriba 2"+"\nSi la variable es velocidad inicial escriba 3"+"\nSi la variable es aceleración escriba 4");
            string variable = Console.ReadLine();
            int numero = 0;
            bool canConvert = int.TryParse(variable, out numero);

            if (canConvert == true)
            {
                if (numero == 1)
                {
                    Console.WriteLine("fórmula del tiempo en MRU");

                    Console.WriteLine("Escribe la velocidad final");
                    vf = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine("Escribe la velocidad inicial");
                    vi = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine("Escribe la aceleración");
                    a = Convert.ToDouble(Console.ReadLine());

                    t = (vf - vi) / a;
                    Console.WriteLine("El tiempo del MRU es " + t);
                }
                else if (numero == 2)
                {
                    Console.WriteLine("fórmula de la velocidad final en MRU");

                    Console.WriteLine("Escribe la velocidad inicial");
                    vi = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine("Escribe la aceleración");
                    a = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine("Escribe el tiempo");
                    t = Convert.ToDouble(Console.ReadLine());

                    vf = vi + a * t;
                    Console.WriteLine("El tiempo del MRU es " + vf);
                }
                else if (numero == 3)
                {
                    Console.WriteLine("fórmula de la velocidad inicial en MRU");

                    Console.WriteLine("Escribe la velocidad final");
                    vf = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine("Escribe la aceleración");
                    a = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine("Escribe el tiempo");
                    t = Convert.ToDouble(Console.ReadLine());

                    vi = vf - a * t;
                    Console.WriteLine("El tiempo del MRU es " + vi);
                }
                else if (numero == 4)
                {
                    Console.WriteLine("fórmula de la aceleración en MRU");

                    Console.WriteLine("Escribe la velocidad final");
                    vf = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine("Escribe la velocidad inicial");
                    vi = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine("Escribe el tiempo");
                    t = Convert.ToDouble(Console.ReadLine());

                    a = (vf - vi) / t;
                    Console.WriteLine("El tiempo del MRU es " + a);
                }
                else
                {
                    Console.WriteLine("Ingrese un número del 1 al 4");
                }
                     Console.ReadKey();
            }
            else
            {
                Console.WriteLine("Dato no válido");
                Console.ReadKey();
            }
        }
    }
}
