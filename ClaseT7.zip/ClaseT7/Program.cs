﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClaseT7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // entradas
            goto ejercicio2;
            string nit;
            int codigo;
            char respuesta = 's'; // s = si, n = no

            Console.WriteLine("Ingrese nit del cliente");
            nit = Console.ReadLine();
            while (respuesta== 's')
            {
                Console.WriteLine("Ingrese código de producto");
                codigo = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Desea ingresar otro producto? s=si, n=no");
                respuesta = Convert.ToChar(Console.ReadLine());
            }
            Console.WriteLine("Gracias por su compra");
            Console.ReadKey();

            ejercicio2:
            int n = 50;
            while (n >= 50 && n <=100)
            {
                Console.WriteLine(n);
                n++;
            }
            Console.WriteLine("FIn del programa");
            Console.ReadKey();
            
        }
    }
}
