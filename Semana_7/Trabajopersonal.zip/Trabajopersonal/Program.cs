﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trabajopersonal
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random r = new Random();
            int sum = 0;

            Console.WriteLine("Ingrese 10 números mayores a 0");
            for (int i = 0; i >= 0) 
            {
                Console.WriteLine(i);
                sum = i + sum;
            }

        }
    }
}
