﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejerciciosemana7
{
    internal class Program
    {
        static void Main(string[] args)
        { // Pablo Bocel, Christopher Yuman, Ricardo Guerra
            Random r = new Random();
            int num = 0;
            int sum = 0;
            Console.WriteLine("Ingrese 100 números");
            
            
            for (int i = 0; i <= 100; i++)
            {
                num = r.Next(100);
                Console.WriteLine(num);
                sum = num + sum;
            }
            Console.WriteLine("El resultado de la suma es "+sum);
            Console.ReadKey();
        }
    }
}
