﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tareaindividual1semana7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double num = 0;
            double sum = 0;
            double prom = 0;
            // Pablo Bocel 1109623

            int i = 0;
            do
            {
                Console.WriteLine("Ingrse un número mayor a 0");
                num = Convert.ToDouble(Console.ReadLine());
                i++;
                sum = num + sum;

                
            }

            while (i < 10);
            
            Console.WriteLine("El promedio es " + sum);
            

            Console.ReadKey();

        }
    }
}
