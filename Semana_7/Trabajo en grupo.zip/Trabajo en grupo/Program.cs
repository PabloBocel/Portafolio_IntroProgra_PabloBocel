﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trabajo_en_grupo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            goto ejercicio2;
            // Pablo Bocel 1109623, Ricardo Guerra 1234123, Christopher Yuman 1160223
            int n = 0;
            int n2 = 0;
            Console.WriteLine("Escribe un numero entero positivo");
            n = Convert.ToInt32(Console.ReadLine()); 
            while (n2 < n)
            {
                n2++;
                Console.WriteLine(n2);
            }
            Console.ReadKey();
        ejercicio2:
            int producto = 0;
            int cantidad = 0;


        }
    }
}
