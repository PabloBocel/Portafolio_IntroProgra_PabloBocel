﻿using System;

class Program
{
    static void Main()
    {
        //Pablo Andres Bocel Morales, Jose Ricardo Guerra Morales, Christopher Javier Yuman Valdez
        goto ejercicio2;
        Random r = new Random();
        int sumaa = 0;

        int num;
        for (int i = 0; i < 100; i++)
        {
            num = r.Next(100);
            Console.WriteLine(num);
            sumaa = num + sumaa;

        }
        Console.WriteLine("La suma es: " + sumaa);
        Console.ReadLine();
    ejercicio2:
        //Pablo Andres Bocel Morales, Jose Ricardo Guerra Morales, Christopher Javier Yuman Valdez
        double estatura = 0;
        double promedio = 0, suma = 0;
        int cont = 0;
        char respuesta;
        do
        {
            Console.WriteLine("Ingrese una estatura");
            estatura = Convert.ToDouble(Console.ReadLine());
            suma = suma + estatura;
            
            cont++;

            Console.WriteLine("Desea ingresar otra estatura? s=si, n=no");
            respuesta = Convert.ToChar(Console.ReadLine());

        } while (respuesta == 's');
        promedio = suma / cont;
        Console.WriteLine("El promedio es:" + promedio);
        Console.ReadLine();
    }
}