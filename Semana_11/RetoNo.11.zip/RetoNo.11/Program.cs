﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetoNo._11
{
    internal class Libro //Pablo Andrés Bocel Morales 1109623
    {
        private int codigoid;
        private string nombre;
        private int cantpag;

        public Libro ()
        {
            codigoid= 0;
            nombre = " ";
            cantpag = 0;
        }

        public string definirLeer( int pagleidas, int cantpag)
        {
            if (pagleidas < cantpag)
            {
                pagleidas++;
                return  "No se ha terminado de leer";
            }
            else if (pagleidas == cantpag)
            {
                return "Libro leído";
            }
            else
            {
                return "Número de páginas inválidas";
            }
            
        }
        public double ObtenerPorcentaje( int pagleidas, int cantpag)
        {
            return ((double)cantpag / (double)(pagleidas)) * 100;
        }
        public int ObtenerPagActual (int pagleidas)
        {
            return pagleidas;
        }
        public string MostrarInfo ()
        {
            return $"El código del libro es {codigoid}, este tiene el nombre de {nombre}, contiene {cantpag} páginas";
        }
        public string ObtenerEstado ( int pagleidas, int cantpag)
        {
            if (pagleidas < cantpag)
            {
                return "En proceso";
            }
            else if (pagleidas == cantpag)
            {
                return "Leído";
            }
            else if (pagleidas == 0)
            {
                return "Libro no leído";
            }
            else
            {
                return "Dato no válido";
            }
        }

        static void Main(string[] args)
        {
            regreso:
            try
            {
                Libro myLibro = new Libro();
                Console.WriteLine("Ingrese el código del libro: ");
                myLibro.codigoid = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Ingrese el nombre del libro: ");
                myLibro.nombre = Console.ReadLine();
                Console.WriteLine("Ingrese la cantidad de páginas del libro: ");
                myLibro.cantpag = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Ingrese la cantidad de páginas leídas: ");
                int pagleidas = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine($"Leer: {myLibro.definirLeer(pagleidas, myLibro.cantpag)}");
                Console.WriteLine(myLibro.MostrarInfo());
                Console.WriteLine($"El porcentaje de lectura es: {myLibro.ObtenerPorcentaje(myLibro.cantpag, pagleidas)}%");
                Console.WriteLine($"La página actual es: {myLibro.ObtenerPagActual(pagleidas)}");
                Console.WriteLine($"EL estado del libro es: {myLibro.ObtenerEstado(pagleidas, myLibro.cantpag)}");
            }
            catch
            {
                Console.WriteLine("Usted ha ingresado un dato inválido");
                goto regreso;
            }
            Console.ReadKey();
        }
    }
}
