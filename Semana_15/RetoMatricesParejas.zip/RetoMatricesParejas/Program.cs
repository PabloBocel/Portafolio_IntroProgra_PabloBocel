﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetoMatricesParejas
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try 
            {
                Console.WriteLine("Cuantos equipos han jugado el torneo?");
                int numequip = Convert.ToInt32(Console.ReadLine());
                string[] nomEquipo = new string[numequip];
                int[] Pjugados = new int[numequip];
                int[] Pganados = new int[numequip];
                int[] Pempatados = new int[numequip];
                int[] Pperdidos = new int[numequip];
                int[] Gfavor = new int[numequip];
                int[] Gcontra = new int[numequip];
                Random r = new Random();
                if (numequip > 1)
                {
                
                    for (int i = 0; i < numequip; i++)
                    {

                        Console.WriteLine("Ingrese el nombre del equipo");
                        string Nombres = Console.ReadLine();

                        while (nomEquipo.Contains(Nombres)) {
                            Console.WriteLine("El nombre ya esta registrado ingrese uno nuevo");
                             Nombres = Console.ReadLine();

                        }
                        
                        nomEquipo[i] = Nombres;

                        for (int j = 0; j < numequip; j++)
                        {
                            Pjugados[j] = r.Next(1, 15);
                            Pganados[j] = r.Next(1, 15);
                            Pempatados[j] = r.Next(1, 15);
                            Pperdidos[j] = r.Next(1, 15);
                            Gfavor[j] = r.Next(1, 15);
                            Gcontra[j] = r.Next(1, 15);
                        }
                           
                    }
                }
                else
                {
                    Console.WriteLine("Ingrese mínimo dos equipos");
                }
                for (int i = 0; i < numequip; i++)
                {
                    Console.WriteLine((i+1)+"."+ nomEquipo[i] +" || "+" PJ "+ Pjugados[i] + " || " + " PG " + Pganados[i] + " || " + " PE " + Pempatados[i] + " || " + " PP " + Pperdidos[i] + " || " + " GF " + Gfavor[i] + " || " + " GC " + Gcontra[i] + " || ");
                }

                Console.ReadKey();
            }
            catch
            {
                Console.WriteLine("Ingrese un dato válido");
                Console.ReadKey();
            }
        }

    }
}
