﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_Semana6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double sueldo = 0;
            double porcentaje = 0.05;
            double total = 0;

            Console.WriteLine("Escribe tu sueldo");
            sueldo = Convert.ToDouble(Console.ReadLine());    

            if (sueldo > 3000) {
                total = sueldo * porcentaje;
                Console.WriteLine("la abonación total es "+ total);
            }
            else
            {
                Console.WriteLine("La abonación es "+ sueldo);
            }
            Console.ReadKey();
        }
    }
}
