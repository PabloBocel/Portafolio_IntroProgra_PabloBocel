﻿using System;

class Program
{
    static void Main()
    {
        //Pablo Andres Bocel Morales, Jose Ricardo Guerra Morales, Christopher Javier Yuman Valdez
        double estatura = 0;
        double promedio = 0, suma = 0;
        int cont = 0;
        char respuesta;
        do
        {
            Console.WriteLine("Ingrese una estatura");
            estatura = Convert.ToDouble(Console.ReadLine());
            suma = suma + estatura;
            
            cont++;

            Console.WriteLine("Desea ingresar otra estatura? s=si, n=no");
            respuesta = Convert.ToChar(Console.ReadLine());

        } while (respuesta == 's');
        promedio = suma / cont;
        Console.WriteLine("El promedio es:" + promedio);
        Console.ReadLine();
    }
}